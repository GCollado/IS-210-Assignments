#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Task 01 module"""


def simple_lookup(var1, var2):
    """Lookup function with exception handling for index and key errors."""
    try:
       return dict(var1[var2])
    except LookupError:
        raise "Warning: Your index/key doesn't exist.\n{}"
        return var1

 
