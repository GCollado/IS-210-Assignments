#!/usr/bin/env python
#-*- coding: utf-8 -*-
"""Returns procuce's arrival and estimated shelf life."""

import produce

TOMATO = produce.Produce()
#Store tomato arrival time and estimated shelf-life

EGGPLANT = produce.Produce(1311210802)
#Returns the eggplant's shelf life

TOMATO_ARRIVAL = TOMATO.arrival
#Returns Tomato's Unix timestamp arrival

EGGPLANT_EXPIRES = EGGPLANT.get_expiration()
#Returns eggplant expiration timestamp
