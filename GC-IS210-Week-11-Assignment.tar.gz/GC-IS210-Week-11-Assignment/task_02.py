#!/usr/bin/env python
# -*- coding: utf-8 *-
"""Creating a class."""

import time


class Snapshot(object):
    """Created atrribute and returns current Unix Timestamp."""

    def __init__(self):
        """Constructor for Snapshot Class.

        Args:
            created (float): Current Unix Timestamp.

        Attributes:
            created (float): Current Unix Timestamp.
        """
        self.created = time.time()
