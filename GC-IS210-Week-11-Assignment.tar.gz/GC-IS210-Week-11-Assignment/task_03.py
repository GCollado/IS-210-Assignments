#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Creating a subclass from an imported class."""

import produce


class Apple(produce.Produce):
    """Imports product function and sets duration of Apples.

    Args:
        duration (int): Duration of apples.

    Attributes:
        duration (int): Duration of apples.

    Returns:
        int: The value of set for duration of apples.

    Examples:
        >>> print Apple.duration
        5356800
    """

    duration = 5356800
