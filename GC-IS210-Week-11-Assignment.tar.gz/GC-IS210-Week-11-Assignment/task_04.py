#!/usr/bin/env python
# = -*- coding: utf-8 -*-
"""Testing has-a and is-a concepts on a subclass."""

import car
class CustomCar(car.Car):
    
    def __init__(self, color, tires=None):
        self.color = car.Car.__init__(self, color)
        self.tires = [tires]
        if self.tires == None:
            for [self.tires] in  xrange(0, 4):
                self.tires.append(tires)

class CustomTire(car.Tire):
    def __init__(self):
        self.__maximum_miles = 500


if __name__ =='__main__':
    CustomTire()

