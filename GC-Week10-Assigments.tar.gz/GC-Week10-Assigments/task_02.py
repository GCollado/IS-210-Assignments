#!/usr/bin/env/python
#-*- coding: utf-8 -*-
"""Access imported dictionaries and return results."""

from data import BANDS

NIGEL = BANDS['Spinal Tap']['Nigel Tufnel']

BAND_NAMES = list(BANDS.keys())
