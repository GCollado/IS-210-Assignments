#!/usr/bin/env python
# -*- coding: utf-8-*-
"""Changing dictionary values."""

import data

data.SUPERHEROES['Logan']['alias'] = 'Wolverine'
