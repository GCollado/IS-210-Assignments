#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Import module, copy attributes, and update tuple elements."""

import data

DIRECTIONS = data.DIRECTIONS

DIRECTIONS = DIRECTIONS[0:-1] + ('West', )
