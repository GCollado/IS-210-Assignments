#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""For loop function to calculate sum (integer) and average (float)."""

def process_data(data):
    total_sum = 0
    counter = 0
    for number in data:
        counter += 1
        total_sum += number
        data_average = float(total_sum/counter)
    return total_sum, data_average
