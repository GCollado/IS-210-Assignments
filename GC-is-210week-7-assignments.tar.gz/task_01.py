#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""fibonnacci sequence."""

def fibonacci(maxint):  #returns fibonacci series up to maxint
    """Returns a list containing the Fibonacci series up to maxint."""
    lastnum, curnum = 0, 1
    result = []
    while lastnum < maxint:
        result.append(lastnum)
        lastnum, curnum = curnum, lastnum+curnum,
    return result
