#!/usr/bin/env python
# -*= coding: utf-8 -*-
"""Returns 'Yes' for True and 'No' for false."""

def bool_to_str(bval):
    """Sets Arg to Bool and returns a string."""
    bval = bool(bval)
    if bval == True:
        return "Yes"
    else:
        return "No"
