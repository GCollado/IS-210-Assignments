#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Functions ask's user's name and saves the variable."""


MY_ANSWER = raw_input("What is your name? ")
