#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Ask a question and store response as int."""

MY_INTEGER = int(
    raw_input('What is the answer to the life the universe and everything? ')
    )
