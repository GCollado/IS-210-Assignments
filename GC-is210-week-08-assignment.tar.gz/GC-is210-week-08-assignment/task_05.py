#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Checks systolic blood pressure and returns BP status."""

BP_STATUS = int(raw_input('What is your blood pressure? '))

if BP_STATUS >= 160:
    BP_STATUS = 'Emergency'
elif BP_STATUS >= 140:
    BP_STATUS = 'High'
elif BP_STATUS >= 120:
    BP_STATUS = 'Warning'
elif BP_STATUS >= 90:
    BP_STATUS = 'Ideal'
else:
    BP_STATUS = 'Low'

print 'Your status is currently: {}!'.format(BP_STATUS)
