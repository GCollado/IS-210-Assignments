#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module provides a function that knows what you mean"""

def know_what_i_mean(wink, numwink=2):
    """Multiples string and int arguments to return to retstr.

    Args:
        wink (str): Takes in string value.
        numwink(int): Takes in int value. Number of winks.

    winks = (wink * numbwink).strip()
    Calculates number of winks by winks and removes whitespace.

    nudges = ('nudge' * numbwink).strip()
    Calculates number of nudges by winks and removes whitespace.

    restr = 'Know what I mean?{}, {}'.format (winks, nudges)
    Inputs winks and nudges into list and formats results.

    Yields:
        returns retstr.

    Examples:
        >>> print iknow_what_i_mean("wink")
        Know what I mean? wink wink nudge nudge
    """

    winks = (wink * numwink).strip()
    nudges = ('nudge ' * numwink).strip()
    retstr = 'Know what I mean? {}, {}'.format(winks, nudges)
    return retstr
