#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module does some pretty crazy math."""

import hamlet

KEYWORD = hamlet.crazy_math(bananas=48, monkeys=84, hours=200000)
