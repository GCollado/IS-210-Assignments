#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compares catfood with the number of kittens and litterboxes."""

def too_many_kittens(kittens, litterboxes, catfood):
    """returns not (litterboxes >= kittens and catfood)

        Args:
           kittens (int): The number of kittens.
           litterboxes (int): The number of litterboxes.
           catfood (bool): Existence of catfood.

        Returns:
           The return value is inversed. True become False
           and False becomes True.
    """

    return not (litterboxes >= kittens and catfood)
