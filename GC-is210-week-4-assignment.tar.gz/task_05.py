#!/usr/bin/env python
#! -*- coding: utf-8 -*-
"""Compares optional and required parameters."""

def defaults(my_required=None, my_optional=True):
    """Returns logical comparison of my_optional and my_required.

    Args:
        my_optional(bool): Default is True.
        my_required(bool): Default is None.
    Return:
        Return value will be True if both parameters are True.
    """
    return my_optional is my_required
