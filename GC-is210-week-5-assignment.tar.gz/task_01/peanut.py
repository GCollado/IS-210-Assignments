#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Two Constants, one returns a truthy vlaue while the other a falsy value."""

BUTTER = True

OIL = False
