#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Imports package module and assigns value to new constant."""

from task_01 import peanut

TIME = peanut.BUTTER
