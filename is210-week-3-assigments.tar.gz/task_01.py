#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Reassign the value of an existing variable.

Strings are immutable but what about the variables that hold them?
"""

RAVEN = 'quoth'
RAVEN = 'Nevermore!'
