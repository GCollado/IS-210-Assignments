#!/usr/env python
# -*- coding: utf-8 -*-
"""Calculates the number of weeks within a year."""


WEEKS = ((19%10 + 100) + 2 ** 8)/7
