#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Slice this string."""


WILL_ROBINSON = 'Danger Will Robinson!'
KLAXON = WILL_ROBINSON[:7]
