#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Repeat our danger."""

import task_03


KLAXON = task_03.KLAXON
KLAXON *= 5
