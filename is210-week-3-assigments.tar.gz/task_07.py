#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Asks the great question."""

import task_06

WORDS = task_06.WORDS

GRANARIES_EXIST = 'granaries' in WORDS

print GRANARIES_EXIST
