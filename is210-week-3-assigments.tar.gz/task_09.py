#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""A computer that can build the question."""

THE_ANSWER_TO_EVERYTHING = 42

INFINITE_IMPROBABILITY = 'browning motion'
